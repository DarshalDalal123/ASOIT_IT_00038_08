let x=50,y=20;
var sum = x + y;
document.write("Sum Of X And Y = ",sum);
var diff = x - y;
document.write("<br> Sub Of X And Y = ",diff);
var mul = x * y;
document.write("<br> Mul Of X And Y = ",mul);
var div = x / y;
document.write("<br> Div Of X And Y = ",div);
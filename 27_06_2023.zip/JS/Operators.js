//Arithmetic
let n1=50,n2=30;
var sum=n1+n2;
var mul=n1*n2;
var sub=n1-n2;
var div=n1/n2;
var mod=n1%n2;
var Exponentiation=5**2; // Same as pow.
document.write("<h1>Arithmetic Operators")
document.write("<br/>Sum:",sum+"<br/>Mul:",mul+"<br/>Sub:",sub+"<br/>Div:",div+"<br/>Modulo:",mod+"<br/>Post Inc:",n1++ +"<br/>Post Dec:",n1--+"<br/>Pre Inc:",++n1+"<br/>Pre Dec:",--n1+"<br/>Exp:",Exponentiation)
var x = 10,y=10,z=10,a=10,b=10,c=10;
x += 50;
y -= 50;
z *= 50;
a /= 50;
b %= 50;
c**=50;
document.write("<h1>Assignment Operators")
document.write("<br/>+=:",x+"<br/>-=:",y+"<br/>*=",z+"<br/>/=:",a+"<br/>%=:",b+"<br/>**=:",c)
var n11=10,n12="10";
document.write("<h1>Conditional Operators")
// == equal to value only.
if(n11==n12){
    document.write("<br/>Same.");
}
else
{
    document.write("<br/>Not Same.");
}

// === equal to value & type.
if(n11===n12){
    document.write("<br/>Same.");
}
else
{
    document.write("<br/>Not Same.");
}

var n13=10,n22=10;

// == equal to value only.
if(n13==n22){
    document.write("<br/>Same.");
}
else
{
    document.write("<br/>Not Same.");
}

// === equal to value & type.
if(n13===n22){
    document.write("<br/>Same.");
}
else
{
    document.write("<br/>Not Same.");
}
// Similar for not equal to and not equal to value and type.
// typeof
// Array instance of
document.write("<h1>Instance Of")
var a = ["Swati", "Solanki"]; 
document.write(a instanceof Array);
document.write("<br/>");
// Class instance of
class Rectangle {
    constructor(height, width) {
      this.height = height;
      this.width = width;
    }
}
var R=new Rectangle(10,20);
document.write(R instanceof Rectangle);
document.write("<br/>");
document.write(R.height+R.width);
document.write("<h1>String Operators")
let s1 = "Darshal";
let s2 = "Dalal";
document.write("<br>");
let s3 = s1 + " " + s2;
document.write(s3);
document.write("<h1>Logical Operators</h1>")
let p=20,q=10;
document.write("<br>");
document.write("Logical AND = Both Condition True then value is True else False<br>");
document.write((p > 10 && q < 20));
document.write("<br>");
document.write("Logical AND = Atleast One Condition True then value is True else False<br>");
document.write((p == 20 || q == 20));
document.write("<br>");
document.write("Logical NOT = returns true for false statements and false for true statements<br>");
document.write(!(p == 10));
let x=20,y=50;
var z=x+y;
document.write("Sum Of X And Y = ",z);
// Numbers:
let length = 16;
let weight = 7.5;
document.getElementById("demo1").innerHTML =
length + "<br>" + weight + "<br>";

// Strings:
let color = "Yellow";
let lastName = "Johnson";
document.getElementById("demo2").innerHTML =
lastName + " would like " + color + " colour";

// Booleans
let x = true;
let y = false;
document.getElementById("demo3").innerHTML =
"Boolean Has Two Values "+ x + " and " + y;

// Object:
const person = {firstName : "John",lastName  : "Doe",age     : 50,eyeColor  : "blue"};
document.getElementById("demo4").innerHTML = person.firstName + " is " + person.age + " years old.";

// Array object:
const cars = ["Saab", "Volvo", "BMW"];
document.getElementById("demo5").innerHTML = cars[0] + " And " + cars[1];

// Date object:
const date = new Date("2022-03-25");
document.getElementById("demo6").innerHTML = date;

var Demo = function(){ 
    return "Hello Welcome to Javascript!"; 
}
document.write("<br/>"+typeof(Demo));
document.write("<br/>"+Demo());

